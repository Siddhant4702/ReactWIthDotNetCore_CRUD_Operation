import React, { Fragment, useEffect, useState } from 'react'
import Table from 'react-bootstrap/Table';

import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


export default function CURD() {

const [name, setName] =useState('');
const [age, setAge]=useState("");
const [isActive, setIsActive] =useState(0);

const [editID, setEditId]=useState('');
const [editname, seteditname] =useState('');
const [editage, seteditage]=useState("");
const [editisActive, seteditisActive] =useState(0);


    const empdata=[
        {
            id : 1,
            name:'Sidd',
            age:19,
            isActive:1
        },
        {
            id:2,
            name:'sidd1',
            age:11,
            isActive:0
        },
        {
            id:3,
            name:'sidd2',
            age:13,
            isActive:1
        }
    ]
    const [data, setData]=useState([]);

    useEffect(()=>{
        setData(empdata);
    },[])

//conclick buttons
const handleEdit=(id)=>{
   // if(window.confirm("Are You want to Edit ???")==true){
     //   alert(id);
     handleShow();
  //  }
}

const handleDelete=(id)=>{
    if(window.confirm("Are You want to Delete???")==true){
        alert(id);
    }
}

const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

//update 
const handleUpdate =()=>{

}



  return (
    <Fragment>

    <Container>
    <Row>
      <Col>
      <input type="text" className='form-control' placeholder='Enter Name'
      value={name} onChange={(e)=>setName(e.target.value)}
      /> 
      </Col>
      <Col>
      <input type="text" className='form-control' placeholder='Enter Age'
        value={age} onChange={(e)=>setAge(e.target.value)}
      />
      </Col>
      <Col>
      <input type="checkbox" 
      checked={isActive===1?true : false}
      onChange={(e)=>handleEdit(e)} value={isActive}
      
      />
      <label>IsActive</label>
      </Col>
      <Col>
        <button className='btn btn-primary'>Submit</button>
      </Col>
    </Row>
    
  </Container>




    <table className="table table-striped table-bordered table-hover">
    <thead>
      <tr>
        <th>#</th>
        <th>Id</th>
        <th>Name</th>
        <th>Age</th>
        <th>IsActive</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      {data && data.length > 0 ? (
        data.map((item, index) => (
          <tr key={index}>
            <td>{index + 1}</td>
            <td>{item.id}</td>
            <td>{item.name}</td>
            <td>{item.age}</td>
            <td>{item.isActive}</td>
            <td>
                <button className='btn btn-primary' onClick={()=>handleEdit(item.id)}>Edit  </button> &nbsp;&nbsp;
                <button className='btn btn-danger' onClick={()=>handleDelete(item.id)}>Delete</button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="5">Loading</td>
        </tr>
      )}
    </tbody>
  </table>


  <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>


      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify/ Update Employee</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
      <Col>
      <input type="text" className='form-control' placeholder='Enter Name' 
      value={editname} onChange={(e)=>seteditname(e.target.value)}
      />
      </Col>
      <Col>
      <input type="text" className='form-control' placeholder='Enter Age'
      value={editage} onChange={(e)=>seteditage(e.target.value)}
      />
      </Col>
      <Col>
      <input type="checkbox" 
      checked={editisActive===1 ? true : false}
      onChange={(e)=>seteditisActive} value={editisActive}
      />
      <label>IsActive</label>
      </Col>
      
    </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </Fragment>
  )
}
