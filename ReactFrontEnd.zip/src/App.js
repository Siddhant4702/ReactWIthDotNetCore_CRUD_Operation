import logo from './logo.svg';
import './App.css';
import CURD from './CURD';

function App() {
  return (
    <CURD/>
  );
}

export default App;
